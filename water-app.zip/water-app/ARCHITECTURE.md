# Gururaghavendra Water Servicing — App Architecture

## 1. Stack

- **Frontend:** React (Vite) + Tailwind CSS
- **Backend:** Firebase (Authentication, Firestore, Hosting, Cloud Functions for admin logic)
- **State:** React Context (`AuthContext`, `CartContext`, `ZoneContext`) — no Redux needed at this scale
- **Routing:** React Router v6

## 2. Folder structure

```
water-app/
├── src/
│   ├── firebase/
│   │   ├── firebaseConfig.js       # Firebase init, reads from .env
│   │   ├── auth.js                 # signUp, login, logout, onAuthChange
│   │   ├── firestore.js            # generic CRUD helpers
│   │   └── orders.js                # order-specific queries (createOrder, subscribeToOrder, etc.)
│   ├── context/
│   │   ├── AuthContext.jsx
│   │   ├── CartContext.jsx
│   │   └── ZoneContext.jsx         # holds "Ankali" | "Outside" + pricing lookup
│   ├── components/
│   │   ├── layout/ (Navbar, Footer)
│   │   ├── product/ (ProductCard, ZoneSelector, QuantityStepper)
│   │   ├── order/ (OrderStatusBadge, OrderTimeline, BottleReturnCheckbox)
│   │   └── ui/ (Button, Modal, Toast — shared droplet-styled primitives)
│   ├── pages/
│   │   ├── CustomerHomepage.jsx    # ← this deliverable
│   │   ├── Login.jsx / Signup.jsx
│   │   ├── CustomerDashboard.jsx   # order history, subscriptions, tracking
│   │   ├── Checkout.jsx
│   │   └── admin/
│   │       ├── AdminDashboard.jsx  # live order queue
│   │       ├── AdminOrderDetail.jsx
│   │       └── AdminBottleLog.jsx
│   ├── hooks/ (useAuth, useZonePricing, useOrders)
│   └── App.jsx / main.jsx
├── firestore.rules
├── .env.example
└── package.json
```

## 3. Firestore schema

### `users/{uid}`
```
name: string
phone: string
address: string
isInsideAnkali: boolean      // drives pricing
role: "customer" | "admin" | "driver"
createdAt: timestamp
```

### `products/{productId}`
```
name: "10L Water Bottle" | "20L Water Bottle"
priceInside: number   // 10 or 15
priceOutside: number  // 10 or 20
description: string
active: boolean
```

### `orders/{orderId}`
```
userId: string
items: [{ productId, name, quantity, priceAtOrder }]
totalAmount: number
deliveryAddress: string
zone: "Ankali" | "Outside"
status: "Pending" | "Out for Delivery" | "Delivered"
paymentMethod: "COD" | "UPI" | "Prepaid" | "Postpaid"
emptyBottlesCollected: number     // bottle return log
timestamp: timestamp
```

### `subscriptions/{subscriptionId}`
```
userId: string
productId: string
quantity: number
frequencyDays: number        // e.g. 2 = every 2 days
nextDeliveryDate: timestamp
active: boolean
```

### `settings/{docId}`
```
deliveryFees: number
activeZones: ["Ankali", "Outside"]
```

## 4. Order status flow

`Pending → Out for Delivery → Delivered`, updated only by admin/driver roles from the Admin Dashboard. Customers get read-only, real-time updates via a Firestore `onSnapshot` listener on their own order doc — this powers the Order Tracking feature without polling.

## 5. Bottle Return Log

Implemented as a field on the order (`emptyBottlesCollected`) rather than a separate collection, since it's always tied to a specific delivery. The driver/admin UI exposes a simple numeric stepper or checkbox-per-bottle at the point of marking an order "Delivered."

## 6. Security model (summary — full rules in `firestore.rules`)

- Customers can only read/write their **own** `users` and `orders` documents.
- `products` and `settings` are public-read, admin-write only.
- Order `status` and `emptyBottlesCollected` can only be changed by admin/driver roles (enforced via a custom claim `role` set through a Cloud Function on signup/promotion — never trust a client-writable `role` field for authorization).
- All writes validate that `totalAmount` and `priceAtOrder` are numbers to block tampering.

## 7. Zone detection

`ZoneContext` defaults to a manual toggle (customer selects "Inside Ankali" / "Outside Ankali") for reliability — geofencing via the Geolocation API can be layered on later as a *suggestion* that pre-selects the toggle, but should never silently override it, since delivery zone directly affects price.

## 8. Next iteration steps

1. ✅ `CustomerHomepage.jsx` with mocked zone/cart state.
2. ✅ `firebaseConfig.js` + `.env`, `AuthContext`, `auth.js`, `Login.jsx` / `Signup.jsx`,
   and the `setUserRole` Cloud Function for safely promoting admins/drivers.
3. Build `CustomerDashboard.jsx` (order history, live tracking, subscriptions).
4. Build `Checkout.jsx` with real Firestore `createOrder`.
5. Build `AdminDashboard.jsx` for order/status/bottle-return management.
6. Deploy `firestore.rules`, deploy the Cloud Function, bootstrap the first
   admin (see comment at the bottom of `functions/index.js`), then `firebase deploy`.

## 9. Auth notes

- `signUp()` creates the Auth account **and** the `users/{uid}` Firestore doc in
  one flow — a user is never left half-created.
- Every new signup defaults to `role: "customer"`. There is intentionally no
  UI path to become `"admin"` or `"driver"` from the client — that only
  happens via the `setUserRole` Cloud Function, callable by an existing admin
  (or bootstrapped once by hand). This is what the Firestore rules trust.
- `AuthContext` reads `role` from the ID token's custom claims, not from the
  Firestore doc, since claims can't be edited by the client. The Firestore
  `role` field is kept in sync for display purposes only.

## 10. Go-live checklist

Everything below is now scaffolded in this project. To actually deploy:

1. **Create the Firebase project**
   - Firebase Console → Add project → name it (e.g. `gururaghavendra-water`).
   - Enable **Authentication** → Email/Password provider.
   - Enable **Firestore Database** → production mode, pick a region close to you (e.g. `asia-south1`).
   - Enable **Hosting**.

2. **Get your config, fill in `.env`**
   - Project Settings → General → Your apps → Add app → Web.
   - Copy the values into a real `.env` file (based on `.env.example`) — never commit it.

3. **Install and run locally**
   ```
   npm install
   npm run dev
   ```
   Confirm signup/login, browsing the homepage, and placing a test order work end to end.

4. **Seed the product catalog**
   - Download a service account key (Project Settings → Service Accounts) → save as `scripts/serviceAccountKey.json` (already gitignored).
   - `npm install firebase-admin` (dev-only dependency, not needed at runtime).
   - `npm run seed`

5. **Deploy Firestore rules and the Cloud Function**
   ```
   npm install -g firebase-tools   # if not already installed
   firebase login
   firebase init                   # link to your project; this creates the real .firebaserc
   firebase deploy --only firestore:rules
   cd functions && npm install && cd ..
   firebase deploy --only functions
   ```

6. **Bootstrap your first admin account**
   - Sign up normally through the app first (creates the Auth user + Firestore profile).
   - From a trusted machine with the service account key, run the one-off snippet at the bottom of `functions/index.js` to grant that user the `admin` claim.
   - Log out and back in (custom claims only take effect on a fresh ID token) — `/admin` should now be reachable.

7. **Build and deploy the frontend**
   ```
   npm run build
   firebase deploy --only hosting
   ```
   Firebase will give you a live `*.web.app` URL.

8. **What's intentionally NOT wired up yet** (safe to launch without, add after):
   - Online prepaid payment (UPI/card gateway) — checkout currently supports COD and "UPI on delivery" only. Wiring a real gateway (Razorpay is the common choice in India) means backend order verification via a Cloud Function; don't skip that step when you add it, or payment status can be spoofed from the client.
   - Subscriptions are modeled in the schema but there's no UI yet to create/manage them.
   - Zone detection is manual toggle only (no geolocation auto-detect).
