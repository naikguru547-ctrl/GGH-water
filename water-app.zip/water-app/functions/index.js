// functions/index.js
//
// Deploy: firebase deploy --only functions
//
// This is the ONLY way `role` should ever be set to "admin" or "driver".
// Call it once manually (via the Firebase console's Functions shell, or
// a temporary authenticated script) to bootstrap your first admin —
// after that, existing admins can call it from an internal tool.

const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.setUserRole = functions.https.onCall(async (data, context) => {
  // Only an existing admin may promote/demote another user.
  if (context.auth?.token?.role !== "admin") {
    throw new functions.https.HttpsError(
      "permission-denied",
      "Only an admin can change user roles."
    );
  }

  const { uid, role } = data;
  if (!uid || !["customer", "driver", "admin"].includes(role)) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Provide a uid and a role of customer, driver, or admin."
    );
  }

  await admin.auth().setCustomUserClaims(uid, { role });

  // Mirror the role onto the Firestore doc too, purely for display —
  // security rules must never rely on this copy, only on the claim.
  await admin.firestore().doc(`users/${uid}`).update({ role });

  return { success: true, uid, role };
});

// --- One-time bootstrap note ---------------------------------------
// To create your very first admin (before any admin exists to call the
// function above), run this once from a trusted environment with the
// Firebase Admin SDK and your service account key:
//
//   admin.auth().setCustomUserClaims("<first-admin-uid>", { role: "admin" });
