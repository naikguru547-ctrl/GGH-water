// scripts/seedProducts.js
//
// Run once after your Firebase project is created:
//   node scripts/seedProducts.js
//
// Requires a service account key — download one from
// Firebase Console → Project Settings → Service Accounts → Generate new
// private key, save it as scripts/serviceAccountKey.json (gitignored),
// and never commit it.

import admin from "firebase-admin";
import { readFileSync } from "fs";

const serviceAccount = JSON.parse(
  readFileSync(new URL("./serviceAccountKey.json", import.meta.url))
);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

async function seed() {
  await db.collection("products").doc("20L").set({
    name: "20 Litre Bottle",
    description: "Household jar, refillable",
    priceInside: 15,
    priceOutside: 20,
    active: true,
  });

  await db.collection("products").doc("10L").set({
    name: "10 Litre Bottle",
    description: "Compact can, easy carry",
    priceInside: 10,
    priceOutside: 10,
    active: true,
  });

  await db.collection("settings").doc("general").set({
    deliveryFees: 0,
    activeZones: ["Ankali", "Outside"],
  });

  console.log("Seeded products + settings.");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
