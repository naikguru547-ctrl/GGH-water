// src/context/AuthContext.jsx
//
// App-wide auth state. Wrap <App /> with <AuthProvider> in main.jsx.
//
// `role` comes from the ID token's custom claims (set by the
// setUserRole Cloud Function), NOT from the Firestore user doc —
// claims can't be forged by the client, a doc field could be.
// `profile` is the Firestore users/{uid} doc (name, phone, address,
// isInsideAnkali) for convenience in UI.

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/firebaseConfig";
import {
  onAuthChange,
  signUp as signUpRequest,
  logIn as logInRequest,
  logOut as logOutRequest,
} from "../firebase/auth";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [role, setRole] = useState("customer");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribeAuth = onAuthChange(async (firebaseUser) => {
      setUser(firebaseUser);

      if (firebaseUser) {
        const tokenResult = await firebaseUser.getIdTokenResult();
        setRole(tokenResult.claims.role || "customer");
      } else {
        setRole("customer");
        setProfile(null);
      }

      setLoading(false);
    });

    return unsubscribeAuth;
  }, []);

  // Live-sync the Firestore profile doc while logged in.
  useEffect(() => {
    if (!user) return;

    const unsubscribeProfile = onSnapshot(doc(db, "users", user.uid), (snap) => {
      if (snap.exists()) setProfile(snap.data());
    });

    return unsubscribeProfile;
  }, [user]);

  const signUp = useCallback(async (details) => {
    const newUser = await signUpRequest(details);
    return newUser;
  }, []);

  const logIn = useCallback(async (email, password) => {
    const loggedInUser = await logInRequest(email, password);
    return loggedInUser;
  }, []);

  const logOut = useCallback(async () => {
    await logOutRequest();
  }, []);

  const value = {
    user,
    profile,
    role,
    isAdmin: role === "admin",
    isDriver: role === "driver",
    loading,
    signUp,
    logIn,
    logOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside an AuthProvider");
  return ctx;
}
