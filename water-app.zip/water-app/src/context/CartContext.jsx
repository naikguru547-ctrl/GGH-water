// src/context/CartContext.jsx
//
// Cart lives here instead of inside CustomerHomepage's local state, so
// Checkout.jsx (a different route) can read the same cart.

import React, { createContext, useContext, useState, useMemo } from "react";

const CartContext = createContext(null);

// Keep in sync with the `products` Firestore collection — productId here
// must match the Firestore document ID so Checkout can look up
// priceInside/priceOutside at order time.
export const PRODUCTS = [
  {
    id: "20L",
    name: "20 Litre Bottle",
    tagline: "Household jar, refillable",
    priceInside: 15,
    priceOutside: 20,
  },
  {
    id: "10L",
    name: "10 Litre Bottle",
    tagline: "Compact can, easy carry",
    priceInside: 10,
    priceOutside: 10,
  },
];

export function CartProvider({ children }) {
  const [zone, setZone] = useState("Ankali"); // "Ankali" | "Outside"
  const [quantities, setQuantities] = useState({ "20L": 1, "10L": 0 });

  function setQuantity(productId, qty) {
    setQuantities((prev) => ({ ...prev, [productId]: Math.max(0, qty) }));
  }

  const items = useMemo(
    () =>
      PRODUCTS.filter((p) => quantities[p.id] > 0).map((p) => ({
        productId: p.id,
        name: p.name,
        quantity: quantities[p.id],
        priceAtOrder: zone === "Ankali" ? p.priceInside : p.priceOutside,
      })),
    [quantities, zone]
  );

  const totalAmount = useMemo(
    () => items.reduce((sum, i) => sum + i.priceAtOrder * i.quantity, 0),
    [items]
  );

  const cartCount = useMemo(
    () => items.reduce((sum, i) => sum + i.quantity, 0),
    [items]
  );

  function clearCart() {
    setQuantities({ "20L": 0, "10L": 0 });
  }

  const value = {
    zone,
    setZone,
    quantities,
    setQuantity,
    items,
    totalAmount,
    cartCount,
    clearCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside a CartProvider");
  return ctx;
}
