// src/firebase/auth.js
//
// Thin wrapper around Firebase Auth + the matching Firestore user profile.
// Signup always creates a `users/{uid}` doc with role "customer" — role
// changes to "admin" / "driver" happen out-of-band via a Cloud Function,
// never through a client write (see functions/index.js: setUserRole).

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
} from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "./firebaseConfig";

/**
 * Create an auth account + matching Firestore profile.
 * @param {{ name: string, phone: string, address: string, isInsideAnkali: boolean, email: string, password: string }} details
 */
export async function signUp({ name, phone, address, isInsideAnkali, email, password }) {
  const { user } = await createUserWithEmailAndPassword(auth, email, password);

  await updateProfile(user, { displayName: name });

  await setDoc(doc(db, "users", user.uid), {
    name,
    phone,
    address,
    isInsideAnkali,
    role: "customer", // default; only a Cloud Function can change this
    createdAt: serverTimestamp(),
  });

  return user;
}

export async function logIn(email, password) {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  return user;
}

export async function logOut() {
  await signOut(auth);
}

/**
 * Subscribe to auth state changes.
 * @param {(user: import("firebase/auth").User | null) => void} callback
 * @returns {() => void} unsubscribe function
 */
export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}
