// src/firebase/orders.js

import {
  collection,
  addDoc,
  doc,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebaseConfig";

/**
 * Create a new order. Called from Checkout.jsx.
 * @param {{
 *   userId: string,
 *   items: Array<{productId: string, name: string, quantity: number, priceAtOrder: number}>,
 *   totalAmount: number,
 *   deliveryAddress: string,
 *   zone: "Ankali" | "Outside",
 *   paymentMethod: "COD" | "UPI" | "Prepaid" | "Postpaid",
 * }} order
 */
export async function createOrder(order) {
  const docRef = await addDoc(collection(db, "orders"), {
    ...order,
    status: "Pending",
    emptyBottlesCollected: 0,
    timestamp: serverTimestamp(),
  });
  return docRef.id;
}

/**
 * Live-subscribe to a single customer's order history, newest first.
 * @param {string} userId
 * @param {(orders: Array<object>) => void} callback
 * @returns {() => void} unsubscribe
 */
export function subscribeToUserOrders(userId, callback) {
  const q = query(
    collection(db, "orders"),
    where("userId", "==", userId),
    orderBy("timestamp", "desc")
  );
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

/**
 * Live-subscribe to ALL orders (admin/driver only — matches firestore.rules).
 * @param {(orders: Array<object>) => void} callback
 * @returns {() => void} unsubscribe
 */
export function subscribeToAllOrders(callback) {
  const q = query(collection(db, "orders"), orderBy("timestamp", "desc"));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

/**
 * Update an order's status and/or bottle return count (staff only).
 * @param {string} orderId
 * @param {{status?: string, emptyBottlesCollected?: number}} changes
 */
export async function updateOrder(orderId, changes) {
  await updateDoc(doc(db, "orders", orderId), changes);
}
