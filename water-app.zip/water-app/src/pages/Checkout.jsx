import React, { useState } from "react";
import { Droplets, MapPin, Wallet, CheckCircle2, AlertCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { createOrder } from "../firebase/orders";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

const PAYMENT_METHODS = [
  { id: "COD", label: "Cash on delivery" },
  { id: "UPI", label: "UPI (pay on delivery)" },
];

export default function Checkout({ onOrderPlaced }) {
  const { user, profile } = useAuth();
  const { items, totalAmount, zone, clearCart } = useCart();

  const [address, setAddress] = useState(profile?.address || "");
  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState("");
  const [placedOrderId, setPlacedOrderId] = useState(null);

  async function handlePlaceOrder() {
    if (!user) {
      setError("Please log in to place an order.");
      return;
    }
    if (items.length === 0) {
      setError("Your cart is empty — add a bottle first.");
      return;
    }
    if (!address.trim()) {
      setError("Add a delivery address so we know where to bring it.");
      return;
    }

    setError("");
    setPlacing(true);
    try {
      const orderId = await createOrder({
        userId: user.uid,
        items,
        totalAmount,
        deliveryAddress: address.trim(),
        zone,
        paymentMethod,
      });
      setPlacedOrderId(orderId);
      clearCart();
      onOrderPlaced?.(orderId);
    } catch (err) {
      setError("Couldn't place your order — please try again.");
    } finally {
      setPlacing(false);
    }
  }

  if (placedOrderId) {
    return (
      <div
        className="min-h-screen bg-cyan-50 flex items-center justify-center px-5"
        style={{ fontFamily: "'Manrope', sans-serif" }}
      >
        <style>{FONTS}</style>
        <div className="bg-white rounded-[2rem] shadow-xl p-8 max-w-sm w-full text-center">
          <div className="h-14 w-14 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 size={28} />
          </div>
          <h1
            className="text-2xl font-bold text-slate-800 mb-2"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Order placed
          </h1>
          <p className="text-sm text-slate-500 mb-1">
            Order #{placedOrderId.slice(0, 8).toUpperCase()}
          </p>
          <p className="text-sm text-slate-500">
            We'll update the status as it moves from Pending to Out for
            Delivery to Delivered — check your dashboard anytime.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cyan-50"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      <header className="bg-teal-900 text-white py-5">
        <div className="max-w-2xl mx-auto px-5 flex items-center gap-2">
          <Droplets size={20} className="text-cyan-300" />
          <span
            className="font-bold text-lg"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Checkout
          </span>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-5 py-8 space-y-5">
        {error && (
          <div className="flex items-start gap-2 bg-rose-50 text-rose-700 text-sm rounded-2xl px-4 py-3">
            <AlertCircle size={16} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Order summary */}
        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-cyan-100">
          <h2
            className="font-bold text-slate-800 mb-4"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Your order · {zone === "Ankali" ? "Inside Ankali" : "Outside Ankali"}
          </h2>

          {items.length === 0 ? (
            <p className="text-sm text-slate-400">
              Your cart is empty. Go back to the homepage to add bottles.
            </p>
          ) : (
            <div className="space-y-3">
              {items.map((item) => (
                <div
                  key={item.productId}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-slate-700">
                    {item.name} × {item.quantity}
                  </span>
                  <span className="font-semibold text-slate-800">
                    ₹{item.priceAtOrder * item.quantity}
                  </span>
                </div>
              ))}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="font-bold text-slate-800">Total</span>
                <span
                  className="font-extrabold text-teal-700 text-lg"
                  style={{ fontFamily: "'Fraunces', serif" }}
                >
                  ₹{totalAmount}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Delivery address */}
        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-cyan-100">
          <h2
            className="font-bold text-slate-800 mb-4 flex items-center gap-2"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            <MapPin size={18} className="text-teal-600" /> Delivery address
          </h2>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            rows={3}
            placeholder="House / street / landmark"
            className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-800 outline-none focus:border-teal-500 transition-colors resize-none"
          />
        </div>

        {/* Payment method */}
        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-cyan-100">
          <h2
            className="font-bold text-slate-800 mb-4 flex items-center gap-2"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            <Wallet size={18} className="text-teal-600" /> Payment method
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {PAYMENT_METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => setPaymentMethod(m.id)}
                className={`rounded-2xl border px-4 py-3 text-sm font-semibold transition-colors ${
                  paymentMethod === m.id
                    ? "border-teal-600 bg-teal-50 text-teal-800"
                    : "border-slate-200 text-slate-600"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-slate-400 mt-3">
            Online prepaid checkout (card/netbanking) isn't wired up yet —
            see the note in ARCHITECTURE.md about adding a payment gateway.
          </p>
        </div>

        <button
          onClick={handlePlaceOrder}
          disabled={placing || items.length === 0}
          className="w-full py-4 rounded-full bg-amber-400 text-teal-900 font-bold hover:bg-amber-300 transition-colors disabled:opacity-60"
        >
          {placing ? "Placing order…" : `Place order · ₹${totalAmount}`}
        </button>
      </div>
    </div>
  );
}
