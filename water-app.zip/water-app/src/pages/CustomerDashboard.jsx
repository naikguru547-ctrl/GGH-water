import React, { useEffect, useState } from "react";
import { Droplets, Package, Truck, CheckCircle2, Clock } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { subscribeToUserOrders } from "../firebase/orders";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

const STATUS_STEPS = ["Pending", "Out for Delivery", "Delivered"];

const STATUS_STYLE = {
  Pending: { icon: Clock, color: "text-amber-600 bg-amber-50" },
  "Out for Delivery": { icon: Truck, color: "text-teal-600 bg-teal-50" },
  Delivered: { icon: CheckCircle2, color: "text-emerald-600 bg-emerald-50" },
};

function StatusTimeline({ status }) {
  const currentIndex = STATUS_STEPS.indexOf(status);
  return (
    <div className="flex items-center gap-1.5 mt-3">
      {STATUS_STEPS.map((step, i) => (
        <React.Fragment key={step}>
          <div
            className={`h-2 flex-1 rounded-full ${
              i <= currentIndex ? "bg-teal-600" : "bg-slate-100"
            }`}
          />
        </React.Fragment>
      ))}
    </div>
  );
}

function OrderCard({ order }) {
  const style = STATUS_STYLE[order.status] || STATUS_STYLE.Pending;
  const Icon = style.icon;

  return (
    <div className="bg-white rounded-3xl p-5 border border-cyan-100 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-slate-400 font-medium">
            #{order.id.slice(0, 8).toUpperCase()}
          </p>
          <p className="text-sm text-slate-700 mt-0.5">
            {order.items?.map((i) => `${i.name} × ${i.quantity}`).join(", ")}
          </p>
        </div>
        <span
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full ${style.color}`}
        >
          <Icon size={13} />
          {order.status}
        </span>
      </div>

      <StatusTimeline status={order.status} />

      <div className="flex items-center justify-between mt-3">
        <span className="text-xs text-slate-400">{order.deliveryAddress}</span>
        <span
          className="font-extrabold text-teal-700"
          style={{ fontFamily: "'Fraunces', serif" }}
        >
          ₹{order.totalAmount}
        </span>
      </div>
    </div>
  );
}

export default function CustomerDashboard() {
  const { user, profile } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsubscribe = subscribeToUserOrders(user.uid, (data) => {
      setOrders(data);
      setLoading(false);
    });
    return unsubscribe;
  }, [user]);

  return (
    <div
      className="min-h-screen bg-cyan-50"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      <header className="bg-teal-900 text-white py-6">
        <div className="max-w-3xl mx-auto px-5 flex items-center gap-2">
          <Droplets size={20} className="text-cyan-300" />
          <div>
            <span
              className="font-bold text-lg block"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              {profile?.name ? `${profile.name}'s orders` : "Your orders"}
            </span>
            <span className="text-xs text-cyan-200">
              {profile?.isInsideAnkali ? "Inside Ankali" : "Outside Ankali"}
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-5 py-8">
        {loading ? (
          <p className="text-sm text-slate-400">Loading your orders…</p>
        ) : orders.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-cyan-100">
            <Package size={28} className="mx-auto text-slate-300 mb-3" />
            <p className="text-slate-500 text-sm">
              No orders yet — head to the homepage to place your first order.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
