import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Droplets,
  MapPin,
  Truck,
  RotateCcw,
  Repeat,
  ShoppingCart,
  Plus,
  Minus,
  Menu,
  X,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useCart, PRODUCTS } from "../context/CartContext";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

function ZoneToggle({ zone, setZone }) {
  return (
    <div className="inline-flex items-center rounded-full bg-white/10 backdrop-blur-sm p-1 border border-white/20">
      {["Ankali", "Outside"].map((z) => (
        <button
          key={z}
          onClick={() => setZone(z)}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
            zone === z
              ? "bg-white text-teal-800 shadow-md"
              : "text-cyan-50 hover:text-white"
          }`}
        >
          <MapPin size={14} />
          {z === "Ankali" ? "Inside Ankali" : "Outside Ankali"}
        </button>
      ))}
    </div>
  );
}

function ProductCard({ product, zone, quantity, onChange }) {
  const price = zone === "Ankali" ? product.priceInside : product.priceOutside;

  return (
    <div className="relative bg-white rounded-[2rem] p-6 shadow-lg shadow-teal-900/10 border border-cyan-100 flex flex-col overflow-hidden group hover:shadow-xl hover:shadow-teal-900/15 transition-shadow duration-300">
      <Droplets
        className="absolute -right-4 -top-4 text-cyan-50 group-hover:text-cyan-100 transition-colors duration-300"
        size={110}
        strokeWidth={1}
      />

      <div className="relative flex items-start justify-between">
        <div>
          <h3
            className="text-xl font-bold text-slate-800"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            {product.name}
          </h3>
          <p className="text-sm text-slate-500 mt-0.5">{product.tagline}</p>
        </div>
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
          <Droplets size={26} />
        </div>
      </div>

      <div className="relative mt-6 flex items-end justify-between">
        <div>
          <span
            className="text-3xl font-extrabold text-teal-700 transition-all duration-300"
            style={{ fontFamily: "'Fraunces', serif" }}
            key={price}
          >
            ₹{price}
          </span>
          <span className="text-sm text-slate-400"> / bottle</span>
        </div>

        <div className="flex items-center gap-2 rounded-full bg-slate-50 border border-slate-200 px-1.5 py-1.5">
          <button
            onClick={() => onChange(Math.max(0, quantity - 1))}
            className="h-7 w-7 rounded-full flex items-center justify-center bg-white text-teal-700 shadow-sm active:scale-95 transition-transform"
            aria-label={`Decrease ${product.name} quantity`}
          >
            <Minus size={14} />
          </button>
          <span className="w-5 text-center text-sm font-bold text-slate-700">
            {quantity}
          </span>
          <button
            onClick={() => onChange(quantity + 1)}
            className="h-7 w-7 rounded-full flex items-center justify-center bg-teal-600 text-white shadow-sm active:scale-95 transition-transform"
            aria-label={`Increase ${product.name} quantity`}
          >
            <Plus size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }) {
  return (
    <div className="rounded-3xl bg-white/70 backdrop-blur-sm border border-cyan-100 p-6 hover:bg-white transition-colors duration-300">
      <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-400 text-white flex items-center justify-center mb-4">
        <Icon size={20} />
      </div>
      <h4 className="font-bold text-slate-800 mb-1">{title}</h4>
      <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
}

export default function CustomerHomepage() {
  const { user, logOut } = useAuth();
  const { zone, setZone, quantities, setQuantity, cartCount, totalAmount } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      className="min-h-screen bg-cyan-50"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      {/* ---------------- NAVBAR ---------------- */}
      <header className="sticky top-0 z-30 bg-teal-900/95 backdrop-blur-sm text-white">
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-cyan-300 to-teal-500 flex items-center justify-center">
              <Droplets size={18} className="text-teal-900" />
            </div>
            <span
              className="font-bold text-lg tracking-tight"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Gururaghavendra Water
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-cyan-50">
            <a href="#products" className="hover:text-white transition-colors">Order</a>
            <a href="#subscribe" className="hover:text-white transition-colors">Subscription</a>
            {user && (
              <Link to="/dashboard" className="hover:text-white transition-colors">
                Track Order
              </Link>
            )}
            <a href="#about" className="hover:text-white transition-colors">About</a>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/checkout"
              className="relative h-10 w-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <ShoppingCart size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-amber-400 text-teal-900 text-xs font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            {user ? (
              <button
                onClick={logOut}
                className="px-4 py-2 rounded-full bg-white text-teal-800 text-sm font-semibold hover:bg-cyan-50 transition-colors"
              >
                Log out
              </button>
            ) : (
              <Link
                to="/login"
                className="px-4 py-2 rounded-full bg-white text-teal-800 text-sm font-semibold hover:bg-cyan-50 transition-colors"
              >
                Login
              </Link>
            )}
          </div>

          <button
            className="md:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden px-5 pb-4 flex flex-col gap-3 text-cyan-50 text-sm font-medium">
            <a href="#products">Order</a>
            <a href="#subscribe">Subscription</a>
            {user && <Link to="/dashboard">Track Order</Link>}
            <a href="#about">About</a>
            <Link to="/checkout">Cart ({cartCount})</Link>
            {user ? (
              <button onClick={logOut} className="text-left">Log out</button>
            ) : (
              <Link
                to="/login"
                className="mt-1 px-4 py-2 rounded-full bg-white text-teal-800 text-sm font-semibold w-fit"
              >
                Login
              </Link>
            )}
          </div>
        )}
      </header>

      {/* ---------------- HERO ---------------- */}
      <section className="relative bg-gradient-to-b from-teal-900 via-teal-800 to-teal-700 text-white overflow-hidden">
        <div className="max-w-6xl mx-auto px-5 pt-14 pb-24 grid md:grid-cols-2 gap-10 items-center relative z-10">
          <div>
            <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider bg-white/10 border border-white/20 rounded-full px-3 py-1 text-cyan-100">
              <Droplets size={12} /> Fresh, filtered, on your doorstep
            </span>
            <h1
              className="mt-5 text-4xl md:text-5xl font-bold leading-[1.1]"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Clean water,
              <br />
              delivered like clockwork.
            </h1>
            <p className="mt-4 text-cyan-100/90 text-base md:text-lg max-w-md">
              Set your zone, pick your bottles, and let us handle the rest —
              from a single order to a standing delivery every two days.
            </p>

            <div className="mt-6 flex flex-col gap-3">
              <span className="text-xs font-semibold uppercase tracking-wide text-cyan-200">
                Your delivery zone
              </span>
              <ZoneToggle zone={zone} setZone={setZone} />
            </div>

            <div className="mt-8 flex items-center gap-4">
              <a
                href="#products"
                className="px-6 py-3 rounded-full bg-amber-400 text-teal-900 font-bold text-sm hover:bg-amber-300 transition-colors shadow-lg shadow-amber-900/20"
              >
                Order water now
              </a>
              <a
                href="#subscribe"
                className="px-6 py-3 rounded-full border border-white/30 text-white font-semibold text-sm hover:bg-white/10 transition-colors"
              >
                Set up a subscription
              </a>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-[2rem] bg-white/10 backdrop-blur-md border border-white/20 p-6 shadow-2xl">
              <p className="text-xs font-semibold uppercase tracking-wide text-cyan-200 mb-4">
                Today's price · {zone === "Ankali" ? "Inside Ankali" : "Outside Ankali"}
              </p>
              <div className="space-y-3">
                {PRODUCTS.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between rounded-2xl bg-white/10 px-4 py-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-cyan-300/20 flex items-center justify-center">
                        <Droplets size={16} className="text-cyan-200" />
                      </div>
                      <span className="text-sm font-medium">{p.name}</span>
                    </div>
                    <span
                      className="text-xl font-extrabold text-amber-300"
                      style={{ fontFamily: "'Fraunces', serif" }}
                    >
                      ₹{zone === "Ankali" ? p.priceInside : p.priceOutside}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <svg
          className="absolute bottom-0 left-0 w-full text-cyan-50"
          viewBox="0 0 1440 100"
          fill="currentColor"
          preserveAspectRatio="none"
        >
          <path d="M0,64 C240,100 480,20 720,40 C960,60 1200,100 1440,56 L1440,100 L0,100 Z" />
        </svg>
      </section>

      {/* ---------------- PRODUCTS ---------------- */}
      <section id="products" className="max-w-6xl mx-auto px-5 py-16">
        <div className="flex items-end justify-between mb-8 flex-wrap gap-4">
          <div>
            <h2
              className="text-3xl font-bold text-slate-800"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Choose your bottles
            </h2>
            <p className="text-slate-500 mt-1">
              Pricing updates instantly with your zone.
            </p>
          </div>
          {cartCount > 0 && (
            <div className="flex items-center gap-3 bg-teal-800 text-white rounded-full pl-4 pr-1.5 py-1.5">
              <span className="text-sm font-semibold">
                {cartCount} bottle{cartCount > 1 ? "s" : ""} · ₹{totalAmount}
              </span>
              <Link
                to="/checkout"
                className="px-4 py-2 rounded-full bg-amber-400 text-teal-900 text-sm font-bold hover:bg-amber-300 transition-colors"
              >
                Checkout
              </Link>
            </div>
          )}
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {PRODUCTS.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              zone={zone}
              quantity={quantities[p.id] || 0}
              onChange={(q) => setQuantity(p.id, q)}
            />
          ))}
        </div>
      </section>

      {/* ---------------- FEATURES ---------------- */}
      <section id="subscribe" className="bg-white/60 py-16">
        <div className="max-w-6xl mx-auto px-5">
          <h2
            className="text-3xl font-bold text-slate-800 mb-8"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Built for regulars
          </h2>
          <div className="grid sm:grid-cols-3 gap-5">
            <FeatureCard
              icon={Repeat}
              title="Recurring delivery"
              desc="Set water to arrive every 2 days — or whatever schedule fits your household. Pause or change it anytime."
            />
            <FeatureCard
              icon={Truck}
              title="Live order tracking"
              desc="Every order moves through Pending → Out for Delivery → Delivered, and you'll see it update in real time."
            />
            <FeatureCard
              icon={RotateCcw}
              title="Bottle return log"
              desc="Empty bottles collected at each delivery are logged automatically, so nothing gets lost in the count."
            />
          </div>
        </div>
      </section>

      {/* ---------------- FOOTER ---------------- */}
      <footer id="about" className="bg-teal-900 text-cyan-100 py-10">
        <div className="max-w-6xl mx-auto px-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Droplets size={18} className="text-cyan-300" />
            <span
              className="font-bold text-white"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Gururaghavendra Water Servicing
            </span>
          </div>
          <p className="text-sm text-cyan-200/80">
            Serving Ankali and surrounding areas · Mineral water home delivery
          </p>
        </div>
      </footer>
    </div>
  );
}
