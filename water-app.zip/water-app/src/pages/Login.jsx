import React, { useState } from "react";
import { Droplets, Mail, Lock, AlertCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

export default function Login({ onSuccess, onNavigateToSignup }) {
  const { logIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await logIn(email, password);
      onSuccess?.();
    } catch (err) {
      setError("Couldn't sign you in — check your email and password and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-teal-900 via-teal-800 to-cyan-50 flex items-center justify-center px-5"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-cyan-300 to-teal-500 flex items-center justify-center">
            <Droplets size={20} className="text-teal-900" />
          </div>
          <span
            className="font-bold text-lg text-white"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Gururaghavendra Water
          </span>
        </div>

        <div className="bg-white rounded-[2rem] shadow-2xl p-8">
          <h1
            className="text-2xl font-bold text-slate-800 mb-1"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Welcome back
          </h1>
          <p className="text-sm text-slate-500 mb-6">
            Log in to order water or check your delivery.
          </p>

          {error && (
            <div className="flex items-start gap-2 bg-rose-50 text-rose-700 text-sm rounded-2xl px-4 py-3 mb-4">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <label className="block">
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                Email
              </span>
              <div className="mt-1.5 flex items-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 focus-within:border-teal-500 transition-colors">
                <Mail size={16} className="text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 outline-none text-sm text-slate-800"
                  placeholder="you@example.com"
                />
              </div>
            </label>

            <label className="block">
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                Password
              </span>
              <div className="mt-1.5 flex items-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 focus-within:border-teal-500 transition-colors">
                <Lock size={16} className="text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="flex-1 outline-none text-sm text-slate-800"
                  placeholder="••••••••"
                />
              </div>
            </label>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-full bg-amber-400 text-teal-900 font-bold text-sm hover:bg-amber-300 transition-colors disabled:opacity-60"
            >
              {submitting ? "Signing in…" : "Log in"}
            </button>
          </form>

          <p className="text-sm text-slate-500 text-center mt-6">
            New here?{" "}
            <button
              onClick={onNavigateToSignup}
              className="text-teal-700 font-semibold hover:underline"
            >
              Create an account
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
