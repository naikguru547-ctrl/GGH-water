import React, { useState } from "react";
import { Droplets, Mail, Lock, User, Phone, MapPin, AlertCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

function Field({ icon: Icon, label, ...inputProps }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
        {label}
      </span>
      <div className="mt-1.5 flex items-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 focus-within:border-teal-500 transition-colors">
        <Icon size={16} className="text-slate-400 shrink-0" />
        <input
          {...inputProps}
          className="flex-1 outline-none text-sm text-slate-800 min-w-0"
        />
      </div>
    </label>
  );
}

export default function Signup({ onSuccess, onNavigateToLogin }) {
  const { signUp } = useAuth();
  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
    isInsideAnkali: true,
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function update(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await signUp(form);
      onSuccess?.();
    } catch (err) {
      if (err?.code === "auth/email-already-in-use") {
        setError("That email already has an account — try logging in instead.");
      } else if (err?.code === "auth/weak-password") {
        setError("Password should be at least 6 characters.");
      } else {
        setError("Couldn't create your account. Please check your details and try again.");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-teal-900 via-teal-800 to-cyan-50 flex items-center justify-center px-5 py-10"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-cyan-300 to-teal-500 flex items-center justify-center">
            <Droplets size={20} className="text-teal-900" />
          </div>
          <span
            className="font-bold text-lg text-white"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Gururaghavendra Water
          </span>
        </div>

        <div className="bg-white rounded-[2rem] shadow-2xl p-8">
          <h1
            className="text-2xl font-bold text-slate-800 mb-1"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Create your account
          </h1>
          <p className="text-sm text-slate-500 mb-6">
            A few details so we can get water to your door.
          </p>

          {error && (
            <div className="flex items-start gap-2 bg-rose-50 text-rose-700 text-sm rounded-2xl px-4 py-3 mb-4">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field
              icon={User}
              label="Full name"
              type="text"
              required
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              placeholder="Your name"
            />
            <Field
              icon={Phone}
              label="Phone number"
              type="tel"
              required
              value={form.phone}
              onChange={(e) => update("phone", e.target.value)}
              placeholder="10-digit mobile number"
            />
            <Field
              icon={MapPin}
              label="Delivery address"
              type="text"
              required
              value={form.address}
              onChange={(e) => update("address", e.target.value)}
              placeholder="House / street / landmark"
            />

            <div>
              <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                Delivery zone
              </span>
              <div className="mt-1.5 inline-flex w-full rounded-2xl bg-slate-50 border border-slate-200 p-1">
                {[true, false].map((val) => (
                  <button
                    type="button"
                    key={String(val)}
                    onClick={() => update("isInsideAnkali", val)}
                    className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-colors ${
                      form.isInsideAnkali === val
                        ? "bg-teal-700 text-white"
                        : "text-slate-500"
                    }`}
                  >
                    {val ? "Inside Ankali" : "Outside Ankali"}
                  </button>
                ))}
              </div>
            </div>

            <Field
              icon={Mail}
              label="Email"
              type="email"
              required
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="you@example.com"
            />
            <Field
              icon={Lock}
              label="Password"
              type="password"
              required
              minLength={6}
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              placeholder="At least 6 characters"
            />

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-full bg-amber-400 text-teal-900 font-bold text-sm hover:bg-amber-300 transition-colors disabled:opacity-60"
            >
              {submitting ? "Creating account…" : "Create account"}
            </button>
          </form>

          <p className="text-sm text-slate-500 text-center mt-6">
            Already have an account?{" "}
            <button
              onClick={onNavigateToLogin}
              className="text-teal-700 font-semibold hover:underline"
            >
              Log in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
