import React, { useEffect, useState, useMemo } from "react";
import { Droplets, Truck, CheckCircle2, Clock, Minus, Plus } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { subscribeToAllOrders, updateOrder } from "../../firebase/orders";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;700;800&display=swap');
`;

const STATUS_TABS = ["All", "Pending", "Out for Delivery", "Delivered"];

const STATUS_COLOR = {
  Pending: "text-amber-700 bg-amber-50 border-amber-200",
  "Out for Delivery": "text-teal-700 bg-teal-50 border-teal-200",
  Delivered: "text-emerald-700 bg-emerald-50 border-emerald-200",
};

const NEXT_STATUS = {
  Pending: "Out for Delivery",
  "Out for Delivery": "Delivered",
};

function OrderRow({ order }) {
  const [bottles, setBottles] = useState(order.emptyBottlesCollected || 0);

  async function advanceStatus() {
    const next = NEXT_STATUS[order.status];
    if (!next) return;
    await updateOrder(order.id, { status: next });
  }

  async function saveBottles(value) {
    const clamped = Math.max(0, value);
    setBottles(clamped);
    await updateOrder(order.id, { emptyBottlesCollected: clamped });
  }

  return (
    <div className="bg-white rounded-3xl p-5 border border-cyan-100 shadow-sm grid md:grid-cols-[1fr_auto_auto_auto] gap-4 items-center">
      <div>
        <p className="text-xs text-slate-400 font-medium">
          #{order.id.slice(0, 8).toUpperCase()} ·{" "}
          {order.zone === "Ankali" ? "Inside Ankali" : "Outside Ankali"}
        </p>
        <p className="text-sm font-semibold text-slate-800 mt-0.5">
          {order.items?.map((i) => `${i.name} × ${i.quantity}`).join(", ")}
        </p>
        <p className="text-xs text-slate-500 mt-0.5">{order.deliveryAddress}</p>
      </div>

      <span
        className={`text-xs font-bold px-3 py-1.5 rounded-full border whitespace-nowrap ${
          STATUS_COLOR[order.status]
        }`}
      >
        {order.status}
      </span>

      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-400">Bottles back</span>
        <div className="flex items-center gap-1 rounded-full bg-slate-50 border border-slate-200 px-1 py-1">
          <button
            onClick={() => saveBottles(bottles - 1)}
            className="h-6 w-6 rounded-full flex items-center justify-center bg-white text-teal-700 shadow-sm"
          >
            <Minus size={12} />
          </button>
          <span className="w-5 text-center text-xs font-bold">{bottles}</span>
          <button
            onClick={() => saveBottles(bottles + 1)}
            className="h-6 w-6 rounded-full flex items-center justify-center bg-teal-600 text-white shadow-sm"
          >
            <Plus size={12} />
          </button>
        </div>
      </div>

      {NEXT_STATUS[order.status] && (
        <button
          onClick={advanceStatus}
          className="px-4 py-2 rounded-full bg-teal-800 text-white text-xs font-bold whitespace-nowrap hover:bg-teal-700 transition-colors"
        >
          Mark {NEXT_STATUS[order.status]}
        </button>
      )}
    </div>
  );
}

export default function AdminDashboard() {
  const { isAdmin, isDriver, loading: authLoading } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("Pending");

  useEffect(() => {
    if (!isAdmin && !isDriver) return;
    const unsubscribe = subscribeToAllOrders((data) => {
      setOrders(data);
      setLoading(false);
    });
    return unsubscribe;
  }, [isAdmin, isDriver]);

  const filtered = useMemo(
    () => (tab === "All" ? orders : orders.filter((o) => o.status === tab)),
    [orders, tab]
  );

  const counts = useMemo(() => {
    const c = { Pending: 0, "Out for Delivery": 0, Delivered: 0 };
    orders.forEach((o) => {
      if (c[o.status] !== undefined) c[o.status]++;
    });
    return c;
  }, [orders]);

  if (!authLoading && !isAdmin && !isDriver) {
    return (
      <div className="min-h-screen bg-cyan-50 flex items-center justify-center px-5">
        <p className="text-slate-500 text-sm">
          This page is only available to staff accounts.
        </p>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cyan-50"
      style={{ fontFamily: "'Manrope', sans-serif" }}
    >
      <style>{FONTS}</style>

      <header className="bg-teal-900 text-white py-6">
        <div className="max-w-4xl mx-auto px-5 flex items-center gap-2">
          <Droplets size={20} className="text-cyan-300" />
          <span
            className="font-bold text-lg"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Order queue
          </span>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-5 py-8">
        <div className="flex gap-2 mb-6 flex-wrap">
          {STATUS_TABS.map((s) => (
            <button
              key={s}
              onClick={() => setTab(s)}
              className={`px-4 py-2 rounded-full text-sm font-semibold border transition-colors ${
                tab === s
                  ? "bg-teal-800 text-white border-teal-800"
                  : "bg-white text-slate-600 border-slate-200"
              }`}
            >
              {s}
              {counts[s] !== undefined && counts[s] > 0 && ` (${counts[s]})`}
            </button>
          ))}
        </div>

        {loading ? (
          <p className="text-sm text-slate-400">Loading orders…</p>
        ) : filtered.length === 0 ? (
          <p className="text-sm text-slate-400">No orders in this view.</p>
        ) : (
          <div className="space-y-4">
            {filtered.map((order) => (
              <OrderRow key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
